const players = {
  'ALmegdad294': {
    id: '',
    badges: 'Detective Fox Badge',
    medals: 'Foxes Honor Medal',
    joinDate: 'May 23',
    image: '1.jpg'
  },
  'Alzyesno': {
    id: '',
    badges: 'Wise Fox & Fox Savior',
    medals: 'Foxes Honor Medal',
    joinDate: 'May 24',
    image: '2.jpg'
  },
  'MM': {
    id: '',
    badges: 'Ghost Fox Badge',
    medals: 'Foxes Honor Medal',
    joinDate: 'May 27',
    image: '3.jpg'
  },
  'Bepo00001': {
    id: '',
    badges: 'Speed Fox',
    medals: '',
    joinDate: 'May 27',
    image: '4.jpg'
  },
  'AliMirghani': {
    id: '',
    badges: 'Darkness Fox',
    medals: '',
    joinDate: 'May 27',
    image: '5.jpg'
  },
  'xenoxflame': {
    id: '',
    badges: 'Fire Fox',
    medals: '',
    joinDate: 'June 11',
    image: '6.jpg'
  },
  'AhmedAamir': {
    id: '',
    badges: 'Navigator Fox',
    medals: '',
    joinDate: 'June 12',
    image: '7.jpg'
  }
};
